﻿using SalesInvoice.Models;

namespace SalesInvoice.RepositoryLayer
{
    public interface IInvoiceRepository
    {
        Task<Invoice> GetInvoiceById(int invoiceId);
        Task<IEnumerable<Invoice>> GetAllInvoices();
        Task AddInvoice(Invoice invoice);
        Task UpdateInvoice(Invoice invoice);
        Task DeleteInvoice(int invoiceId);
    }

}
