﻿using SalesInvoice.Models;

namespace SalesInvoice.RepositoryLayer
{
    public interface IItemRepository
    {
        Task<Item> GetItemById(int itemId);
        Task<IEnumerable<Item>> GetAllItems();
        Task AddItem(Item item);
        Task UpdateItem(Item item);
        Task DeleteItem(int itemId);
    }
}
