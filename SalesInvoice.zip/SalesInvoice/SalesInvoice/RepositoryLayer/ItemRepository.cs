﻿using SalesInvoice.Models;

namespace SalesInvoice.RepositoryLayer
{
    public class ItemRepository : IItemRepository
    {
        private readonly DbContext _context;

        public ItemRepository(DbContext context)
        {
            _context = context;
        }

        public async Task<Item> GetItemById(int itemId)
        {
            return await _context.Set<Item>().FindAsync(itemId);
        }

        public async Task<IEnumerable<Item>> GetAllItems()
        {
            return await _context.Set<Item>().ToListAsync();
        }

        public async Task AddItem(Item item)
        {
            await _context.Set<Item>().AddAsync(item);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateItem(Item item)
        {
            _context.Entry(item).State = EntityState.Modified;
            await _context.SaveChangesAsync();
        }

        public async Task DeleteItem(int itemId)
        {
            var item = await _context.Set<Item>().FindAsync(itemId);
            if (item != null)
            {
                _context.Set<Item>().Remove(item);
                await _context.SaveChangesAsync();
            }
        }
    }

}
