﻿using SalesInvoice.Models;
using System.Data.Entity;
using System.Data;

namespace SalesInvoice.RepositoryLayer
{
    public class InvoiceItemRepository : IInvoiceItemRepository
    {
        private readonly DbContext _context;

        public InvoiceItemRepository(DbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<InvoiceItem>> GetInvoiceItemsByInvoiceId(int invoiceId)
        {
            return await _context.Set<InvoiceItem>().Where(ii => ii.InvoiceId == invoiceId).ToListAsync();
        }

        public async Task AddInvoiceItem(InvoiceItem invoiceItem)
        {
            await _context.Set<InvoiceItem>().AddAsync(invoiceItem);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateInvoiceItem(InvoiceItem invoiceItem)
        {
            _context.Entry(invoiceItem).State = EntityState.Modified;
            await _context.SaveChangesAsync();
        }

        public async Task DeleteInvoiceItem(int invoiceItemId)
        {
            var invoiceItem = await _context.Set<InvoiceItem>().FindAsync(invoiceItemId);
            if (invoiceItem != null)
            {
                _context.Set<InvoiceItem>().Remove(invoiceItem);
                await _context.SaveChangesAsync();
            }
        }
    }

}
