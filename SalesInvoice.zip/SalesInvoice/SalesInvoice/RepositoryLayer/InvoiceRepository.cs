﻿using SalesInvoice.Models;

namespace SalesInvoice.RepositoryLayer
{
    public class InvoiceRepository : IInvoiceRepository
    {
        private readonly DbContext _context;

        public InvoiceRepository(DbContext context)
        {
            _context = context;
        }

        public async Task<Invoice> GetInvoiceById(int invoiceId)
        {
            return await _context.Set<Invoice>().FindAsync(invoiceId);
        }

        public async Task<IEnumerable<Invoice>> GetAllInvoices()
        {
            return await _context.Set<Invoice>().ToListAsync();
        }

        public async Task AddInvoice(Invoice invoice)
        {
            await _context.Set<Invoice>().AddAsync(invoice);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateInvoice(Invoice invoice)
        {
            _context.Entry(invoice).State = EntityState.Modified;
            await _context.SaveChangesAsync();
        }

        public async Task DeleteInvoice(int invoiceId)
        {
            var invoice = await _context.Set<Invoice>().FindAsync(invoiceId);
            if (invoice != null)
            {
                _context.Set<Invoice>().Remove(invoice);
                await _context.SaveChangesAsync();
            }
        }
    }

}
