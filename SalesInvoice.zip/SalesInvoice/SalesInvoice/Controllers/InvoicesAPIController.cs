﻿using Microsoft.AspNetCore.Mvc;
using SalesInvoice.Models;
using SalesInvoice.ServiceLayer;

namespace SalesInvoice.Controllers
{
    public class InvoicesAPIController : Controller
    {
        [Route("api/invoices")]
        [ApiController]
        public class InvoicesController : ControllerBase
        {
            private readonly IInvoiceService _invoiceService;

            public InvoicesController(IInvoiceService invoiceService)
            {
                _invoiceService = invoiceService;
            }

            [HttpGet]
            public async Task<ActionResult<IEnumerable<Invoice>>> GetInvoices()
            {
                var invoices = await _invoiceService.GetAllInvoices();
                return Ok(invoices);
            }

            [HttpGet("{invoiceId}")]
            public async Task<ActionResult<Invoice>> GetInvoice(int invoiceId)
            {
                var invoice = await _invoiceService.GetInvoiceById(invoiceId);
                if (invoice == null)
                {
                    return NotFound();
                }

                return Ok(invoice);
            }

            [HttpPost]
            public async Task<ActionResult<Invoice>> CreateInvoice(Invoice invoice)
            {
                await _invoiceService.AddInvoice(invoice);

                // Return the created invoice
                return CreatedAtAction(nameof(GetInvoice), new { invoiceId = invoice.Id }, invoice);
            }

            [HttpPut("{invoiceId}")]
            public async Task<IActionResult> UpdateInvoice(int invoiceId, Invoice invoice)
            {
                var existingInvoice = await _invoiceService.GetInvoiceById(invoiceId);
                if (existingInvoice == null)
                {
                    return NotFound();
                }

                // Update properties from request object
                existingInvoice.InvoiceDateTime = invoice.InvoiceDateTime;
                existingInvoice.InvoiceNo = invoice.InvoiceNo;
                existingInvoice.InvoiceCustomerName = invoice.InvoiceCustomerName;
                existingInvoice.InvoiceCustomerMobileNo = invoice.InvoiceCustomerMobileNo;
                existingInvoice.ActualAmount = invoice.ActualAmount;
                existingInvoice.InvoiceCustomerName = invoice.InvoiceCustomerName;
                existingInvoice.PaidAmount = invoice.PaidAmount;
                existingInvoice.PaymentMode = invoice.PaymentMode;

                await _invoiceService.UpdateInvoice(existingInvoice);

                return NoContent();
            }

            [HttpDelete("{invoiceId}")]
            public async Task<IActionResult> DeleteInvoice(int invoiceId)
            {
                var existingInvoice = await _invoiceService.GetInvoiceById(invoiceId);
                if (existingInvoice == null)
                {
                    return NotFound();
                }

                await _invoiceService.DeleteInvoice(invoiceId);

                return NoContent();
            }

        }
    }
}