﻿namespace SalesInvoice.Models
{
    public class Invoice
    {
        public int Id { get; set; } // Primary Key
        public string InvoiceNo { get; set; } // YYMMDDHHMMSS-8DigitRandomText
        public DateTime InvoiceDateTime { get; set; } // YYYY-MM-DD HH:mm:ss
        public string InvoiceCustomerName { get; set; }
        public string InvoiceCustomerMobileNo { get; set; }
        public decimal ActualAmount { get; set; }
        public decimal DiscountInRs { get; set; }
        public decimal PaidAmount { get; set; }
        public string PaymentMode { get; set; } // CASH, UPI, CARD, OTHER
    }
}
