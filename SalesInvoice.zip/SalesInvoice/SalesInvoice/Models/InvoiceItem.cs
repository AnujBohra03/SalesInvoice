﻿namespace SalesInvoice.Models
{
    public class InvoiceItem
    {
        public int Id { get; set; } // Primary Key
        public int InvoiceId { get; set; } // Foreign Key referencing Invoice.Id
        public int ItemId { get; set; } // Foreign Key referencing Item.Id
        public int ItemQuantity { get; set; }
        public decimal ItemUnitPrice { get; set; }
        public decimal ItemDiscount { get; set; }
        public decimal ItemAmountPaid { get; set; }
    }
}
