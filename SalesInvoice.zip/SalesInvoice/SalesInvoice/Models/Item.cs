﻿namespace SalesInvoice.Models
{
    public class Item
    {
        public int Id { get; set; } // Primary Key
        public string ItemCode { get; set; } // Must be 6 digits long
        public string ItemName { get; set; }
        public string ItemCategory { get; set; } // A, B, or C
        public decimal ItemUnitPrice { get; set; }
        public decimal ItemDiscountInPercentage { get; set; }
    }
}
