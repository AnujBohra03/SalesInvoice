﻿using SalesInvoice.Models;
using SalesInvoice.RepositoryLayer;

namespace SalesInvoice.ServiceLayer
{
    public class InvoiceService : IInvoiceService
    {
        private readonly IInvoiceRepository _invoiceRepository;

        public InvoiceService(IInvoiceRepository invoiceRepository)
        {
            _invoiceRepository = invoiceRepository;
        }

        public async Task<Invoice> GetInvoiceById(int invoiceId)
        {
            return await _invoiceRepository.GetInvoiceById(invoiceId);
        }

        public async Task<IEnumerable<Invoice>> GetAllInvoices()
        {
            return await _invoiceRepository.GetAllInvoices();
        }

        public async Task AddInvoice(Invoice invoice)
        {
            await _invoiceRepository.AddInvoice(invoice);
        }

        public async Task UpdateInvoice(Invoice invoice)
        {
            await _invoiceRepository.UpdateInvoice(invoice);
        }

        public async Task DeleteInvoice(int invoiceId)
        {
            await _invoiceRepository.DeleteInvoice(invoiceId);
        }
    }

}
