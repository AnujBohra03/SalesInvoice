﻿using SalesInvoice.Models;

namespace SalesInvoice.ServiceLayer
{
    public interface IItemService
    {
        Task<Item> GetItemById(int itemId);
        Task<IEnumerable<Item>> GetAllItems();
        Task AddItem(Item item);
        Task UpdateItem(Item item);
        Task DeleteItem(int itemId);
    }

}
