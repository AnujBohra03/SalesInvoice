﻿using SalesInvoice.Models;
using SalesInvoice.RepositoryLayer;

namespace SalesInvoice.ServiceLayer
{
    public class InvoiceItemService : IInvoiceItemService
    {
        private readonly IInvoiceItemRepository _invoiceItemRepository;

        public InvoiceItemService(IInvoiceItemRepository invoiceItemRepository)
        {
            _invoiceItemRepository = invoiceItemRepository;
        }

        public async Task<IEnumerable<InvoiceItem>> GetInvoiceItemsByInvoiceId(int invoiceId)
        {
            return await _invoiceItemRepository.GetInvoiceItemsByInvoiceId(invoiceId);
        }

        public async Task AddInvoiceItem(InvoiceItem invoiceItem)
        {
            await _invoiceItemRepository.AddInvoiceItem(invoiceItem);
        }

        public async Task UpdateInvoiceItem(InvoiceItem invoiceItem)
        {
            await _invoiceItemRepository.UpdateInvoiceItem(invoiceItem);
        }

        public async Task DeleteInvoiceItem(int invoiceItemId)
        {
            await _invoiceItemRepository.DeleteInvoiceItem(invoiceItemId);
        }
    }

}
