﻿using SalesInvoice.Models;
using SalesInvoice.RepositoryLayer;

namespace SalesInvoice.ServiceLayer
{
    public class ItemService : IItemService
    {
        private readonly IItemRepository _itemRepository;

        public ItemService(IItemRepository itemRepository)
        {
            _itemRepository = itemRepository;
        }

        public async Task<Item> GetItemById(int itemId)
        {
            return await _itemRepository.GetItemById(itemId);
        }

        public async Task<IEnumerable<Item>> GetAllItems()
        {
            return await _itemRepository.GetAllItems();
        }

        public async Task AddItem(Item item)
        {
            await _itemRepository.AddItem(item);
        }

        public async Task UpdateItem(Item item)
        {
            await _itemRepository.UpdateItem(item);
        }

        public async Task DeleteItem(int itemId)
        {
            await _itemRepository.DeleteItem(itemId);
        }
    }

}
