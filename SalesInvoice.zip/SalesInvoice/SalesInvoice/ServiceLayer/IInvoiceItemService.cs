﻿using SalesInvoice.Models;

namespace SalesInvoice.ServiceLayer
{
    public interface IInvoiceItemService
    {
        Task<IEnumerable<InvoiceItem>> GetInvoiceItemsByInvoiceId(int invoiceId);
        Task AddInvoiceItem(InvoiceItem invoiceItem);
        Task UpdateInvoiceItem(InvoiceItem invoiceItem);
        Task DeleteInvoiceItem(int invoiceItemId);
    }

}
